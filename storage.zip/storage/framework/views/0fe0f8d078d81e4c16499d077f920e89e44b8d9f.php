

<?php $__env->startSection('content'); ?>

<div class="container mt-3">
    <div class="card">
        <div class="card-header">
            <h3>Tambah Produk</h3>
        </div>
        <div class="card-body">
            <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-primary mb-3">Kembali</a>
            <form action="<?php echo e(route('barang.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <ul class="list-group">
                    Produk <input type="text" name="nama" required>
                    Brand <input type="text" name="brand" required>
                    Harga <input type="text"  name="harga" required>
                    <label for="exampleInputEmail1" class="form-label">Masukan Foto</label>
                    <input name="foto" type="file" class="form-control" required>
                </ul>
                <input type="submit" value="Simpan Data" class="btn btn-success mt-3">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepatuku\resources\views/barang/add.blade.php ENDPATH**/ ?>