

<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-center mt-3">
        <div class="card w-50">
            <div class="card-header">
                <h3>Product</h3>
            </div>
            <div class="card-body">
                
                <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-primary mt-2 mb-2">Kembali</a>
                <div class="row ml-2">
                    <h4 class="">Produk : <?php echo e($barang->nama); ?></h4>
                  
                </div>
                <div class="row ml-2">
                    <h4 class="">Brand : <?php echo e($barang->brand); ?></h4>
                 
                </div>
                <div class="row ml-2">
                    <h4 class="">Harga : <?php echo e($barang->harga); ?></h4>
                   
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepatuku\resources\views/barang/detail.blade.php ENDPATH**/ ?>