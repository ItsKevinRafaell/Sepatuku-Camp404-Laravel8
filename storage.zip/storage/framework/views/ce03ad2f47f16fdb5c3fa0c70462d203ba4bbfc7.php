

<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <div class="card">
            <div class="card-header">
                <h3>Data Produk</h3>
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-primary mt-2 mb-4">Tambah Data Produk</a>
                <table class="table table-bordered table-striped">
                    <tr>
                        <th>Foto</th>
                        <th>Produk</th>
                        <th>Brand</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <img src="<?php echo e(asset('fotoproduk/'.$item->foto)); ?>" style="width: 40px ; height:40px;" alt=""></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->brand); ?></td>
                        <td><?php echo e($item->harga); ?></td>

                    <td>
                        <ul class="nav">
                            <a href="<?php echo e(route ('barang.show', $item->id)); ?>" class="btn btn-success me-2">Show</a>
                            <a href="<?php echo e(route('barang.edit', $item->id)); ?>" class="btn btn-primary me-2">Edit</a>
                            <form action="<?php echo e(route('barang.destroy', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-warning">Delete</button>
                        </form>
                        </ul>
                    </td>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepatuku\resources\views/barang/beranda.blade.php ENDPATH**/ ?>