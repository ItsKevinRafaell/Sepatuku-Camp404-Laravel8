

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <div class="card">
        <div class="card-header">
            <h3>Ubah Data Produk</h3>
        </div>
        <div class="card-body">
            <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-primary mb-3">Kembali</a>
            <form action="<?php echo e(route('barang.update', $barang->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <ul class="list-group">
                    Produk <input type="text" name="nama" required value="<?php echo e($barang->nama); ?>">
                    Brand <input type="text" name="brand" required value="<?php echo e($barang->brand); ?>">
                    Harga <input type="text" name="harga" required value="<?php echo e($barang->harga); ?>">
                    <label for="exampleInputEmail1" class="form-label">Masukan Foto</label>
                    <input name="foto" type="file" class="form-control" required>
                </ul>
                <input type="submit" value="Ubah Data" class="btn btn-success mt-3">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepatuku\resources\views/barang/edit.blade.php ENDPATH**/ ?>