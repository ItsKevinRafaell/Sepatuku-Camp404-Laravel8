

<?php $__env->startSection('content'); ?>

<style>
    body {
background: #333;
}
</style>

    <div class="container d-flex justify-content-center">
        <div class="">
            <div class="card-header text-center mt-5 mb-5">
                <h2 class="text-white">Product</h2>
                <h5 class="text-white">List of the best and rare shoes with best quality, premium, and very cheap price</h5>
            </div>
          
                
            <div class="container mt-3">
                <div class="row ">
                    <?php $__currentLoopData = $databarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 mb-3 ms-4 me-3">
                     
                        <div class="card" style="width: 18rem;">
                            <img class="text-center" src="<?php echo e(asset('fotoproduk/'.$barang->foto)); ?>" style="width: 80px ;margin-left:15px;"  alt="">
                            <div class="card-body">
                              <h5 class="card-title"><?php echo e($barang->nama); ?></h5>
                              <i class="card-text"><?php echo e($barang->brand); ?></i>
                              <p class="card-text"><?php echo e($barang->harga); ?></p>
                            </div>
                          </div>
                    
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
                
              

       
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sepatuku\resources\views/katalog.blade.php ENDPATH**/ ?>